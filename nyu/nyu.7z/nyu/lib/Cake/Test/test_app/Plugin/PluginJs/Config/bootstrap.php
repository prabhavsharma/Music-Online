<?php
Configure::write('CakePluginTest.js_plugin.bootstrap', 'loaded js plugin bootstrap');